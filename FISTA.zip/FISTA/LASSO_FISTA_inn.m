%-------------------------------------------------------------------------
% Nesterov accelerated algorithm for LASSO problems (FISTA algorithm).
%
% Optimization using Nesterov-accelerated approximate point gradient
% method.This algorithm is called by the outer continuous strategy, and the
% inner iterative optimization of a fixed regularization parameter is
% completed under the continuous strategy.
%  
% At each iteration, the algorithm first updates one step based on the
% previous two iteration points: 
% y_k = x_(k-1) + (k-2)/(k+1)[x_(k-1) - x_(k-2)]
% Then perform a one-step approximate point gradient method at y_k:
% x_k = mathrm{prox}(y_k - t_k * A'(A * y_k - b))
%
%-------------------------------------------------------------------------
%% Initialization and iteration preparation
%
% The function will complete the optimization of inner iterations under the
% LASSO continuous strategy.
%
% Input: A, b, �̣�x0, ��0(the regularization coefficient of the original
% problem), opts
% 
% Output: x and out
%
% out.fvec ��the original LASSO problem objective function value for each
% iteration step��corresponds to ��0 of the original problem��
% out.fval ��the original LASSO problem objective function value at
% iteration termination��corresponds to ��0 of the original problem
% out.nrmG ��gradient norm at iteration termination
% out.tt �� run time of the problem
% out.itr ��number of outer iterations
% out.flag ��record whether or not the problem converges
% out.xsd : the sparsity rate, that is, the ratio of the number of zero
% parameters to the number of all parameters

function [x, out] = LASSO_FISTA_inn(x0, A, b, mu, mu0, P, opts)
%%%
% Read the parameters from the input structure OPTS or take the default
% parameters.
%
% opts.maxit ��the maximum number of the outer iterations
% opts.ftol ��stop judgment condition for the function values
% opts.gtol ��stop judgment condition for the gradient
% opts.alpha0 ��the intial stepsize
% optsz.verbose ��if not equal to 0, output each iteration information, otherwise not output
% opts.ls ��mark whether to use the line search method
% opts.bb ��mark whether to use the Barzilar-Borwein (BB) method 

if ~isfield(opts, 'maxit'); opts.maxit = 1000; end
if ~isfield(opts, 'ftol'); opts.ftol = 1e-8; end
if ~isfield(opts, 'gtol'); opts.gtol = 1e-6; end
if ~isfield(opts, 'verbose'); opts.verbose = 1; end
if ~isfield(opts, 'alpha0'); opts.alpha0 = 1e-3; end
if ~isfield(opts, 'ls'); opts.ls = 1; end
if ~isfield(opts, 'bb'); opts.bb = 1; end

%%%
% Initialization
k = 0;
t = opts.alpha0;
tt = tic;
x = x0;
y = x;
xp = x0;

%%%
fp = inf;
r = A*x0 - b;
g = A'*(P.*r);
tmp = 0.5*(r .* P)' * r;
f =  tmp + mu0*norm(x,1);
tmpf = tmp + mu*norm(x,1);
nrmG = norm(x - prox(x - g,mu),2);
out = struct();
out.fvec = tmp + mu0*norm(x,1);
out.xsd = [ ];
out.x = [ ];

%%%
% Parameters of the line search method
Cval = tmpf; Q = 1; gamma = 0.85; rhols = 1e-6;

%% Main loop for the iteration
while k < opts.maxit && nrmG > opts.gtol && abs(f - fp) > opts.ftol
    
    %%%
    % Record the iteration information of the previous step.
    gp = g;
    yp = y;
    fp = tmpf;
    
    %%% 
    % FISTA ---------------------------------------------------------------
    theta = (k - 2) / (k + 1);
    y = x + theta * (x - xp);
    xp = x;
    r = A * y - b;
    g = A'*(P.*r);

    % The stepsize is calculated using the line search method.
    if opts.bb && opts.ls
        dy = y - yp;
        dg = g - gp;
        dyg = abs(dy'*dg);
        if dyg > 0
            if mod(k,2) == 0
                t = norm(dy,2)^2/dyg;
            else
                t = dyg/norm(dg,2)^2;
            end
        end
        t = min(max(t,opts.alpha0),1e12); % Limit the updated BB stepsize t_k to [t_0,10^12].  
    else
        t = opts.alpha0; % If we don't need to calculate the BB step size, just choose the default step size.
    end
    x = prox(y - t*g, t*mu);
    xsd = 1 - sum(x~=0)/length(x);
    out.xsd = [out.xsd,xsd];
    
    % Do a line search when opts.ls=1. Exit after the line search
    % conditions are satisfied or after 5 consecutive step decays, 
    % otherwise the stepsize is decayed by a ratio of 0.2.
    %
    % The line search condition of the 
    % f(x) = 0.5*[norm(Ax - b)]^2 + mu*norm(x,1)
    % is
    % f(x_(k+1)) <= Cval - 0.5*t_k*rho*[norm(x_(k+1) - y_k,2)]^2
    % where,Cval is a auxiliary variable.
    %
    % When the line search conditions are not met, the current stepsize is
    % decreased, and the current line search time is increased by one.
    if opts.ls
        nls = 1;
        while 1
            tmp = 0.5 * ((A*x - b) .* P)' * (A*x - b);
            tmpf = tmp + mu*norm(x,1);
            if tmpf <= Cval - 0.5/t*rhols*norm(x-y,2)^2 || nls == 5
                break;
            end
            t = 0.2*t; nls = nls + 1;
            x = prox(y - t * g, t * mu);
        end

        % Compute the updated function value.
        f = tmp + mu0*norm(x,1);

        % Update non-monotonic line search parameter values.
        Qp = Q; Q = gamma*Qp + 1; Cval = (gamma*Qp*Cval + tmpf)/Q;
        
        % When opts.ls=0, no line search is performed.
    else
        f = 0.5 * ((A*x - b) .* P)' * (A*x - b) + mu0*norm(x,1);
    end
    
    % Gradient
    nrmG = norm(x - y,2)/t;
    %----------------------------------------------------------------------
    
    %%%
    % The iteration time is incremented by one, the current function value
    % is recorded, and the information is output.
    k = k + 1;
    out.fvec = [out.fvec, f];
    out.x = [out.x,x];
    if opts.verbose
        fprintf('itr: %d\tt: %e\tfval: %e\tnrmG: %e\n', k, t, f, nrmG);
    end
    
    %%%
    % In particular, in addition to the above-mentioned stopping criteria,
    % if the function value does not decrease for 10 consecutive steps, the
    % inner loop is stopped.
    if k > 5 && min(out.fvec(k-4:k)) > out.fvec(k-5)
        break;
    end
end

%%%
% When exiting the loop, report the exit mode of the inner iteration to the
% outer iteration (continuous strategy). When the maximum number of
% iterations is reached, 'out.flag' is recorded as 1; otherwise, it is
% recorded as 0, that is, the convergence is achieved. This indicator is
% used to determine whether to decay the regularization parameter.
if k == opts.maxit
    out.flag = 1;
else
    out.flag = 0;
end

%%%
% Record the output information.
out.fvec = out.fvec(1:k);
out.fval = f;
out.itr = k;
out.tt = toc(tt);
out.nrmG = nrmG;

end

%% The auxiliary function
% The adjacent operator mathrm{sign}(x)*max{|x|-mu,0} corresponding to the
% function h(x)=mu*norm(x,1)
function y = prox(x, mu)
y = max(abs(x) - mu, 0);
y = sign(x) .* y;
end

