%-------------------------------------------------------------------------
% FISTA algorithm for LASSO problem: application of sparse regularization in
% spherical radial basis functions (SRBFs) based regional geoid modeling;
% generalized cross validation (GCV) or corrected Akaike information
% criterion (AICc) are used to select the regularization coefficient.
%
% The codes of the FISTA part are originally created by Wen Zaiwen, Liu
% Haoyang and Hu Jiang, see:
% https://bicmr.pku.edu.cn/~wenzw/optbook/pages/lasso_proxg/LASSO_Nesterov_inn.html
%
% Yu Haipeng and Chang Guobin modified the original codes of the FISTA so
% that they can be used for local gravity field modeling based on SRBFs.The
% analytical expressions of GCV and AICc are derived by Chang Guobin and Yu
% Haipeng, who also edited thess parts of the codes.
%
% Yu Haipeng and Chang Guobin,
% School of Environment Science and Spatial Informatics,
% China University of Mining and Technology, Xuzhou, China
% 2021-08-28, last modified 2022-01-20
%
%-------------------------------------------------------------------------

clear all

% ------------------------------------------------------------------------
%% Initialization 

% x0: the initial values of unknown parameters
% N: the number of the SRBFs
% B: the design matrix
% obs: the observation vector
% mu0: the hyperparameter, namely the regularization coefficient
% P: weight matrix, note: to reduce memory requirements, P is a column vector
% sum: the number of observations
% BTP: the auxiliary variable
% L: the Lipschitz constant

N = N;
x0 = zeros(N,1); 
load 'B.mat';
load 'obs.mat';
b = obs;
mu0 = mu0;
load 'P.mat';
BTP = zeros(N,sum);
parpool('local',4); % Parallel operation
parfor i = 1:N
    BTP(i,:) = (B(:,i).*P)'; 
end
delete(gcp);
BTPB = BTP * B;
L = eigs(BTPB,1); 
clear BTP;
clear BTPB;

%% Continuous solution strategy of LASSO
opts.method = 'FISTA';
[x, out] = LASSO_con(x0, B, obs, mu0, L, P, opts); 

%% Regularization parameter selection
n0 = length(nonzeros(x));
sum = length(obs);
RS = obs - B * x;
RSS = (RS .* diag_P)' * RS;
GCV = sum * RSS/(sum - n0)^2;
AICc = sum * log(RSS/sum) + 2 * n0 + 2 * n0 * (n0 + 1)/(sum - n0 -1);