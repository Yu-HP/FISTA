%-------------------------------------------------------------------------
% The continuous strategy for the LASSO problem:
%
% For the LASSO problem, the continuous strategy gradually decreases from a 
% larger regularization parameter ��t to ��0��namely ��1��...�ݦ�t-1�ݦ�t��...�ݦ�0��, 
% and solve the corresponding LASSO problem.
%
% The advantage of this is that when solving the optimization problem
% corresponding to ��t, the solution of the optimization problem
% corresponding to ��t-1 (the ��1 subproblem uses a random initial point) can
% be used as a good approximation solution to complete the solution process
% in a short time.It can be seen that the larger ��t is, the easier it is to
% solve the corresponding LASSO problem. Therefore, the continuous strategy
% is equivalent to speeding up the solution of the original problem by
% quickly solving a series of simple problems (complex problems become
% simpler with a good initial solution).
%  
% After using the iterative algorithm to solve the LASSO problem
% corresponding to ��t, the update formula of the regularization parameter
% ��t+1 is taken as:
% ��t+1 = max{ ��0, ��t * �� }
% here, �ǡ�(0,1) is a reduction factor.
%
%-------------------------------------------------------------------------
%% Initialization and iteration preparation
%
% Input: x0, B, b, mu0, L, P, opts(a struct that provides various input parameters)
%
% Output��x(the iterative solution ) and out(a struct that provides various output parameters)
%
% out.fvec ��function value of each iteration
% out.itr_inn ��total number of the inner iterations
% out.fval ��objective function value at the end of the iteration
% out.tt : run time of the problem
% out.itr ��number of outer iterations
% out.sr : the sparsity rate, that is, the ratio of the number of zero

function [x, out] = LASSO_con(x0, B, b, mu0, L, P, opts) 
%%
% Read the parameters from the input structure OPTS or take the default
% parameters.
%
% opts.maxit ��the maximum number of the outer iterations
% opts.maxit_inn ��the maximum number of the inter iterations
% opts.ftol ��stop judgment condition for the function values
% opts.gtol ��stop judgment condition for the gradient
% opts.factor ��decay rate of the regularization parameter
% opts.verbose ��if not equal to 0, output each iteration information, otherwise not output
% opt.mu1 ��the initial regularization  parameter (with a continuous strategy, starting with larger regularization  parameter)
% opts.alpha0 ��the intial stepsize
% opts.ftol_init_ratio ��magnification of the initial stop judgment condition opts.ftol
% opts.gtol_init_ratio ��magnification of the initial stop judgment condition opts.gtol
% opts.etaf ��the reduction rate of opts. ftol for each outer iteration
% opts.etag ��the reduction rate of opts. gtol for each outer iteration
% opts.opts1 ��struct, it provides additional concrete parameters to the inner algorithm

if ~isfield(opts, 'maxit'); opts.maxit = 1; end
if ~isfield(opts, 'maxit_inn'); opts.maxit_inn = 30; end
if ~isfield(opts, 'ftol'); opts.ftol = 1e1; end  
if ~isfield(opts, 'gtol'); opts.gtol = 1e1; end  
if ~isfield(opts, 'factor'); opts.factor = 0.1; end
if ~isfield(opts, 'verbose'); opts.verbose = 1; end
if ~isfield(opts, 'mu1'); opts.mu1 = 10^5; end  
if ~isfield(opts, 'gtol_init_ratio'); opts.gtol_init_ratio = 1; end  
if ~isfield(opts, 'ftol_init_ratio'); opts.ftol_init_ratio = 1; end  
if ~isfield(opts, 'opts1'); opts.opts1 = struct(); end
if ~isfield(opts, 'etaf'); opts.etaf = 1e-1; end 
if ~isfield(opts, 'etag'); opts.etag = 1e-1; end 
if ~isfield(opts, 'alpha0'); opts.alpha0 = 1/L; end 
if ~isfield(opts, 'method'); error('Need opts.method'); end
algf = eval(sprintf('@LASSO_%s_inn',opts.method));

%%%
% Add the path of the subdirectory to the working path
addpath(genpath(pwd));

%%%
% Iteration preparation, notice that a continuous strategy is adopted, so ��
% starts with a larger 'opts.mu1'.
out = struct();
out.fvec = [];
out.sr = [];
out.x = [];
k = 0;
x = x0;
mu_t = opts.mu1;
tt = tic;

%%%
% The function value corresponding to the current regularization parameter
% ��t and x.
f = Func(B, b, mu_t, x, P);

%%%
% 'opts1' is the set of stopping criterion parameters of the corresponding
% sub-problem solving algorithm when a certain regularization coefficient
% ��t is fixed. 'opts1.ftol' is the threshold for the relative change of the
% function in the stop judgment condition.|opts1.gtol| is the threshold of
% the gradient norm. Note that they both gradually decrease as the outer
% iteration progresses, which requires a gradual increase in the accuracy
% of the sub-problem solution. Initially, larger values are selected for
% these two thresholds.
opts1 = opts.opts1;
opts1.ftol = opts.ftol*opts.ftol_init_ratio;
opts1.gtol = opts.gtol*opts.gtol_init_ratio;
out.itr_inn = 0;

%% The continuous loop
while k < opts.maxit
    %%%
    % opts1.itr��the maximum number of iterations, given by opts.maxit_inn
    % opts1.ftol��stop judgment condition for the function values
    % opts1.gtol��stop judgment condition for the gradient
    % opts1.alpha0��the intial stepsize
    % opts1.verbose��when ops.verbose > 1, detailed output of inner iteration information
    opts1.maxit = opts.maxit_inn;
    opts1.gtol = max(opts1.gtol * opts.etag, opts.gtol);
    opts1.ftol = max(opts1.ftol * opts.etaf, opts.ftol);
    opts1.verbose = opts.verbose > 1;
    opts1.alpha0 = opts.alpha0;
    
    %%%
    % 'opts1.sigma' gives the range of Huber smoothing only if
    % 'opts.method' is 'grad_huber'.
    if strcmp(opts.method, 'grad_huber'); opts1.sigma = 1e-3*mu_t; end
    
    %%%
    % Call the inner loop function and record the return information of
    % each inner loop.
    % 'out.fvec' records the original function value corresponding to x at
    % each step (regularization parameters is ��, not the current ��t).
    fp = f;
    [x, out1] = algf(x, B, b, mu_t, mu0, P, opts1); 
    f = out1.fvec(end);
    out.fvec = [out.fvec, out1.fvec];
    out.sr = [out.sr, out1.sr];
    out.x = [out.x, out1.x];
    k = k + 1;
    
    %%%
    % Since the L1-norm is not differentiable, here 'nrmG' represents the
    % degree of violation of the optimality condition of the LASSO problem.
      r1 = B*x - b;
      g1 = B'*(P.*r1); 
      nrmG = norm(x - prox(x - g1,mu0),2);
    
    %%%
    % Print each outer loop information in detailed output mode.
    if opts.verbose
        fprintf('itr: %d\tmu_t: %e\titr_inn: %d\tfval: %e\tnrmG: %.1e\n', k, mu_t, out1.itr, f, nrmG);
    end
    
    %%%
    % When the inner loop exits due to reaching the convergence condition,
    % reduce the current regularization parameter ��t, and judge the
    % convergence.
    % Convergence condition for outer loop: when �� has decreased to be the
    % same as ��0 and the function value or gradient satisfies the
    % convergence condition, stop the outer loop.
    if ~out1.flag
        mu_t = max(mu_t * opts.factor, mu0);
    end

    if mu_t == mu0 && (nrmG < opts.gtol || abs(f-fp) < opts.ftol)
        break;
    end
    
    %%%
    % Update the total number of iterations.
    out.itr_inn = out.itr_inn + out1.itr;
end

%%%
% When the outer loop terminates, record the current function value, the
% number of outer iterations, and the running time.
out.fval = f;
out.tt = toc(tt);
out.itr = k;

%% The auxiliary function
%%%
% Objective function for the original LASSO problem.
    function f = Func(A, b, mu0, x,inv_Q)
        w = A * x - b;
        f = 0.5 * ( w .* inv_Q)' * w + mu0 * norm(x, 1);
    end

%%%
% The adjacent operator mathrm{sign}(x)*max{|x|-mu,0} corresponding to the
% function h(x)=mu*norm(x,1)
    function y = prox(x, mu)
        y = max(abs(x) - mu, 0);
        y = sign(x) .* y;
    end

end

